import React, {useState, useEffect} from 'react'
import axios from 'axios'

export default function App(){
  const [ats, setAts] = useState('greenhouse')
  const [candidates, setCandidates] = useState([])
  const [selected, setSelected] = useState(null)
  const [jobDesc, setJobDesc] = useState('')
  const [preview, setPreview] = useState('')
  const [subject, setSubject] = useState('')
  const [email, setEmail] = useState('')
  const [sending, setSending] = useState(false)

  useEffect(()=>{fetchCandidates()}, [ats])

  async function fetchCandidates(){
    try {
      const r = await axios.get(`/ats/candidates?ats=${ats}`)
      setCandidates(r.data.candidates)
      setSelected(null)
      setPreview('')
      setJobDesc('')
      setSubject('')
      setEmail('')
    } catch(e) {
      alert('Failed to load candidates: ' + e.message)
    }
  }

  async function fetchDetail(c){
    try {
      const r = await axios.get(`/ats/candidate/${ats}/${c.id}`)
      setSelected(r.data)
      setEmail(r.data.candidate.email || '')
      setPreview('')
      setSubject('')
      setJobDesc('')
    } catch(e) {
      alert('Failed to load candidate detail: ' + e.message)
    }
  }

  async function genPreview(e){
    e.preventDefault()
    if (!jobDesc.trim()) {
      alert('Please enter a job description')
      return
    }
    try {
      const fd = new FormData()
      fd.append('job_description', jobDesc)
      const r = await axios.post(`/ats/candidate/${ats}/${selected.candidate.id}/prepare-outreach`, fd)
      setPreview(r.data.preview)
      setSubject('Opportunity at Our Company')
    } catch(e) {
      alert('Failed to generate preview: ' + e.message)
    }
  }

  async function doSend(e){
    e.preventDefault()
    setSending(true)
    try {
      const fd = new FormData()
      fd.append('to_email', email)
      fd.append('subject', subject || 'Opportunity')
      fd.append('body', preview)
      const r = await axios.post(`/ats/candidate/${ats}/${selected.candidate.id}/send-outreach`, fd)
      alert('Sent / previewed. Screening score: ' + r.data.screening.score)
      setSending(false)
      setPreview('')
      setSubject('')
      setJobDesc('')
    } catch(e) {
      alert('Failed to send outreach: ' + e.message)
      setSending(false)
    }
  }

  return (
    <div className="flex gap-6 p-6 min-h-screen bg-gray-50 font-sans text-gray-900">
      <div className="w-80 flex flex-col">
        <h2 className="text-2xl font-bold mb-4">ATS</h2>
        <select
          className="mb-6 p-2 border rounded"
          value={ats}
          onChange={e => setAts(e.target.value)}
        >
          <option value='greenhouse'>Greenhouse</option>
          <option value='ashby'>Ashby</option>
        </select>
        <h3 className="text-xl font-semibold mb-2">Candidates</h3>
        <div className="flex-1 overflow-auto border border-gray-300 rounded bg-white">
          {candidates.length === 0 && (
            <p className="p-4 text-gray-500">No candidates found.</p>
          )}
          {candidates.map(c => (
            <div
              key={c.id}
              className="p-3 border-b border-gray-200 cursor-pointer hover:bg-indigo-50"
              onClick={() => fetchDetail(c)}
            >
              <p className="font-medium">{c.name}</p>
              <p className="text-sm text-gray-600 truncate">{c.email}</p>
            </div>
          ))}
        </div>
      </div>
      <div className="flex-1 flex flex-col bg-white rounded shadow p-6">
        <h2 className="text-2xl font-bold mb-4">Candidate Detail</h2>
        {!selected && <p className="text-gray-600">Select a candidate</p>}
        {selected && (
          <>
            <h3 className="text-xl font-semibold">{selected.candidate.name}</h3>
            <p className="mb-4"><strong>Email:</strong> {selected.candidate.email}</p>
            <h4 className="font-semibold mb-1">Resume (excerpt)</h4>
            <pre className="mb-4 max-h-72 overflow-auto bg-gray-100 p-3 rounded text-sm whitespace-pre-wrap">{selected.resume_text.slice(0, 2000)}</pre>
            <form onSubmit={genPreview} className="mb-4">
              <label className="block mb-2 font-semibold" htmlFor="jobDesc">Job Description (for outreach)</label>
              <textarea
                id="jobDesc"
                className="w-full p-2 border border-gray-300 rounded mb-3 resize-none"
                rows={6}
                value={jobDesc}
                onChange={e => setJobDesc(e.target.value)}
              />
              <button
                type="submit"
                className="px-4 py-2 bg-indigo-600 text-white rounded hover:bg-indigo-700 transition"
              >
                Generate Outreach Preview
              </button>
            </form>
            {preview && (
              <div>
                <h4 className="font-semibold mb-2">Preview</h4>
                <pre className="mb-4 p-3 bg-gray-50 border border-gray-300 rounded whitespace-pre-wrap">{preview}</pre>
                <form onSubmit={doSend}>
                  <div className="mb-3">
                    <label className="block font-semibold mb-1" htmlFor="email">To</label>
                    <input
                      id="email"
                      className="w-full p-2 border border-gray-300 rounded"
                      value={email}
                      onChange={e => setEmail(e.target.value)}
                      required
                      type="email"
                    />
                  </div>
                  <div className="mb-3">
                    <label className="block font-semibold mb-1" htmlFor="subject">Subject</label>
                    <input
                      id="subject"
                      className="w-full p-2 border border-gray-300 rounded"
                      value={subject}
                      onChange={e => setSubject(e.target.value)}
                      required
                    />
                  </div>
                  <button
                    type="submit"
                    disabled={sending}
                    className={`px-4 py-2 rounded text-white transition ${
                      sending ? 'bg-gray-400 cursor-not-allowed' : 'bg-green-600 hover:bg-green-700'
                    }`}
                  >
                    {sending ? 'Sending...' : 'Send Outreach'}
                  </button>
                </form>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  )
}